# Lab 06 — PHP Web Security & Sessions (Secure Notes) 

**Student Name:** Vanessa da Veiga Caldas
**Date:** 2026/02/15
## 1) What I built (1–2 sentences)
I built a PHP web application with secure login, access control, and sessions.

## 2) How to run my lab
**Database name:** `lab06_Vanessa' 
**Start page URL:** http://localhost/3363winter/lab06/public/index.php
Steps:
1. Start XAMPP (Apache + MySQL)
2. Open phpMyAdmin and create my database lab06_Vanessa
3. Run the Lab06 SQL to create tables: `users`, `notes`
4. Update `app/db.php` with my DB name lab06_Vanessa
5. Open the start page URL above

## 3) Security features checklist:
- password_hash() and password_verify()
- Prepared statements
- Escaping output (XSS prevention)
- Access control (role-based)
- Session timeout
- Session fixation prevention
- Security headers

## 4) Test Results (PASS/FAIL)
- Register works: PASS
- Login works (correct password): PASS
- Login fails (wrong password): PASS
- Dashboard redirects when logged out: PASS
- Create note works: PASS
- XSS test does NOT run (`<script>alert('xss')</script>`): PASS
- Admin page (user gets 403): PASS
- Admin page (admin can view): PASS
- Session timeout works: PASS

## 5) Reflection: what I have learned from Lab 06 (3-5 sentences)
In this lab, I learned how to implement secure login using password_hash() and password_verify(). 
I used prepared statements to prevent SQL injection. 
I applied escaping output to prevent XSS. 
I also implemented access control and session timeout for better security.