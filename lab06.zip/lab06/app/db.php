<?php
declare(strict_types=1);
require_once __DIR__ . "/config.php";
// STUDENT TODO: Update DB_NAME to your database name: lab06_yourfirstname
$DB_HOST = "localhost";
$DB_NAME = "lab06_Vanessa";
$DB_USER = "root";
$DB_PASS = ""; // XAMPP default is empty
$dsn = "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4";
try {
 $pdo = new PDO($dsn, $DB_USER, $DB_PASS, [
 PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
 PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
 ]);
} catch (PDOException $e) {
 die("Database connection failed: " . $e->getMessage());
} 
