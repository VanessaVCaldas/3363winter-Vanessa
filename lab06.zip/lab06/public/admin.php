<?php
declare(strict_types=1);
require_once __DIR__ . "/../app/security.php";
require_once __DIR__ . "/../app/auth.php";
security_headers();
enforce_session_timeout();
require_role("admin");
?>
<!doctype html>
<html lang="en">
<head>
 <meta charset="utf-8">
 <title>Admin</title>
 <link rel="stylesheet" href="style.css"> 
</head>
<body>
<div class="wrapper">

 <h1>Admin Page</h1>
 <p>This content is only visible to admin users.</p>
 <p><a href="dashboard.php">Back to Dashboard</a></p>
</div> 
</body>
</html>