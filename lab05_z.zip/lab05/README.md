# Lab 05 - PHP + MySQL CRUD (PDO)
## Student Info
- Name: Vanessa Caldas
- Course: Advanced Web Design & Development
- Lab: 05
## Database
- Database name: lab05_vanessa
- Table: students
### Schema (SQL)
```sql
CREATE TABLE students (
 student_id INT AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(100) NOT NULL,
 email VARCHAR(120) NOT NULL UNIQUE,
 program VARCHAR(80) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```
## How to Run (Local)
1. Start XAMPP: Apache + MySQL
2. Put project here:
 - C:\xampp\htdocs\winter3363\lab05\
3. Open:
 - http://localhost/3363winte/lab05/public/

 ## Features Completed
- [x] PDO connection (db.php)
- [x] READ (index.php)
- [x] CREATE (create.php)
- [x] UPDATE (edit.php)
- [x] DELETE (delete.php)
- [x] Prepared statements used everywhere
- [x] Output escaped with htmlspecialchars
## Screenshots (Required)
Submit required screenshots in a file to Moodle.
## Notes / Challenges
In this lab, I learned how to connect PHP to MySQL using PDO and prepared statements.  
I also better understood the CRUD flow (create, read, update, and delete data).  
My main challenge was understanding PDO errors when running database queries.