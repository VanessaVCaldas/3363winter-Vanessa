<?php
// Basic header include (no frameworks required)
?>
<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8" />
 <meta name="viewport" content="width=device-width, initial-scale=1" />
 <title>Lab 05 - PDO CRUD</title>
 <style>
 /* Page */
 body {
 font-family: Arial, sans-serif;
 background: #2b2b2b; /* dark gray */
 color: #f2f2f2; /* light text */
 }
 /* Main content panel */
 .container {
 max-width: 980px;
 margin: 0 auto;
 background: #034672; /* slightly lighter panel */
 padding: 20px;
 border-radius: 14px;
 }
 hr { border: 0; border-top: 1px solid #555; }
 /* Top bar */
 .topbar {
 display: flex;
 justify-content: space-between;
 align-items: center;
 margin-bottom: 12px;
 gap: 12px;
 flex-wrap: wrap;
 
 }
 /* Buttons */
 .btn {
 display: inline-block;
 padding: 8px 12px;
 border: 1px solid #ddd;
 text-decoration: none;
 color: #fff;
 background: transparent;
 border-radius: 6px;
 cursor: pointer;
 }
 .btn:hover { background: #585858; }
 .danger { border-color: #ff6b81; color: #ff6b81; }
 .danger:hover { background: rgba(255, 107, 129, 0.15); }
 /* Messages */
 .msg {
 padding: 10px;
 border: 1px solid #666;
 background: #1f1f1f;
 border-radius: 6p;
 margin: 10px 0;
 }
 .error {
 padding: 10px;
 border: 1px solid #ff6b81;
 background: rgba(255, 107, 129, 0.12);
 border-radius: 6px;
 margin: 10px 0;
 }
 /* Forms */
 label { display:block; margin-top: 10px; }
 input[type="text"], input[type="email"] {
 width: 100%;
 padding: 10px;
 border: 1px solid #666;
 border-radius: 8px;
 background: #1f1f1f;
 color: #fff;
 }
 .form-actions {
 margin-top: 14px;
 display: flex;
 gap: 10px;
 align-items: center;
 flex-wrap: wrap;
 }
 .muted { color: #cfcfcf; font-size: 0.95rem; }
 .search { display:flex; gap: 10px; margin-top: 10px; flex-wrap: wrap; }
 .search input[type="text"] { width: 260px; }
 /* TABLE: standout card style */
 table {
 width: 100%;
 border-collapse: separate; /* allows rounded corners */
 border-spacing: 0;
 margin-top: 14px;
 background: #1f1f1f; /* table surface */
 border: 1px solid #555;
 border-radius: 12px;
 overflow: hidden; /* keeps rounded corners */
 }
 th, td {
 padding: 12px 10px;
 text-align: left;
 border-bottom: 1px solid #333; /* subtle separators */
 }
 th {
 background: #111; /* strong header */
 color: #fff;
 font-weight: 700;
 letter-spacing: 0.3px;
 border-bottom: 1px solid #555;
 }
 /* Zebra rows */
 tbody tr:nth-child(even) td {
 background: #242424;
 }
 /* Hover highlight */
 tbody tr:hover td {
 background: #2f2f2f;
 }
 </style>
</head>
<body>
 <div class="container">
 <h1>Lab 05 - Student Tracker (PDO CRUD)</h1>
 <p class="muted">PHP + MySQL (PDO) with prepared statements</p>
 <hr />