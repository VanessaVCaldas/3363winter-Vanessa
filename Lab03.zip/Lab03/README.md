# Lab 03 

This project is a simple PHP login system with server-side validation and sessions.

## How to run (XAMPP)

1. Start **Apache** in XAMPP.
2. Put this folder in:
   `/Applications/XAMPP/xamppfiles/htdocs/3363winter/lab03/`
3. Open in browser:
   http://localhost/3363winter/lab03/

## What this project does

- Builds a login form using POST  
- Validates required fields on the server  
- Checks username and password in PHP  
- Uses PHP sessions to track login  
- Protects a page so only logged-in users can access it  
- Logs out by clearing and destroying the session  

## How to test

- Open the base URL and confirm it redirects to the login page.  
- Submit the form empty and confirm required field errors appear.  
- Submit wrong credentials and confirm an invalid login message appears.  
- Submit correct credentials and confirm you are redirected to the dashboard.  

## Demo credentials

Username: **student**  
Password: **Lab03!**

## Reflection

In this lab I learned how a PHP login system works in practice. I saw how the server checks the form, shows errors, and only allows access when the user is logged in. I also learned that PHP pages must run through a server (XAMPP) and how sessions are used to keep the user logged in between pages.