<?php
// authenticate.php
session_start();
date_default_timezone_set(timezoneId: 'America/Halifax');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function require_login(): void {
    if (empty($_SESSION['logged_in'])) {
        header(header:"location: login.php");
        exit;
    }
}
