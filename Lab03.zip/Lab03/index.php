<?php
header(header:"location: login.php");
exit
?>