# Lab 04 — MySQL Database Design

This project creates a simple MySQL schema using phpMyAdmin, with two related tables (parent → child).

## How to run (XAMPP)

1. Start **Apache** and **MySQL** in XAMPP.  
2. Place this folder in:  
   `/Applications/XAMPP/xamppfiles/htdocs/3363winter/lab04/`  
3. Open in a browser:  
   http://localhost/3363winter/lab04/

## What this project does

- Creates a MySQL schema named `lab04_Vanessa`  
- Creates two related tables:
  - `customers` (parent table)
  - `orders` (child table)
- Defines:
  - Primary Keys with `AUTO_INCREMENT`
  - A parent → child relationship using `customer_id`
- Inserts sample data
- Runs basic SQL queries, including a JOIN
- Exports the database as `lab04_Vanessa.sql`
- Documents the database in `index.php`

---

## Database
Database name: `lab04_Vanessa`  
Table 1 (parent): `customers`  
Table 2 (child): `orders`  
Primary key (Table 1): `customer_id`  
Foreign key (Table 2): `customer_id`  

## Data
Rows in Table 1: 3  
Rows in Table 2: 3  

## JOIN query I ran
```sql
SELECT c.customer_id, c.first_name, c.last_name, c.email,
       o.order_id, o.order_date, o.total_amount, o.status
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
ORDER BY o.order_date DESC;