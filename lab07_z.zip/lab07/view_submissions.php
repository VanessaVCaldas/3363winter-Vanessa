<?php
// view_submissions.php
$dataFile = __DIR__ . "/data/submissions.jsonl";
$rows = [];
if (file_exists($dataFile)) 
    {
    $lines = file($dataFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $obj = json_decode($line, true); // decode JSON line into an associative array if (is_array($obj)) {
        $rows[] = $obj; 
    }
}
// Simple escape helper 
function e(string $v): string {
    return htmlspecialchars($v, ENT_QUOTES, "UTF-8"); }
?>
<!DOCTYPE html> <html lang="en"> <head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1"/> <title>Lab 07 - View Submissions</title>
<style>
body { font-family: Arial, sans-serif; padding: 20px; }
table { border-collapse: collapse; width: 100%; }
th, td { border: 1px solid #ccc; padding: 8px; text-align: left; } th { background: #f2f2f2; }
</style> </head> <body>
<h1>Saved Submissions</h1>
<?php if (empty($rows)): ?>
<p>No submissions found yet.</p>
<?php else: ?> <table>
<thead>
    <tr>
<th>#</th> <th>Name</th> <th>Email</th> <th>Course</th> <th>Rating</th> <th>Comments</th> <th>Created At</th>
</tr> </thead> <tbody>
<?php foreach ($rows as $i => $r): ?> <tr>
<td><?= $i + 1 ?></td>
<td><?= e((string)($r["name"] ?? "")) ?></td> <td><?= e((string)($r["email"] ?? "")) ?></td> <td><?= e((string)($r["course"] ?? "")) ?></td> <td><?= e((string)($r["rating"] ?? "")) ?></td> <td><?= e((string)($r["comments"] ?? "")) ?></td> <td><?= e((string)($r["created_at"] ?? "")) ?></td>
</tr>
<?php endforeach; ?>
</tbody> </table>
<?php endif; ?>
<p><a href="index.php">Back to form</a></p> </body>
</html>