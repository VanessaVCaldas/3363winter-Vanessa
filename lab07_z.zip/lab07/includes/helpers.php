<?php

function e(string $value): string {
 return htmlspecialchars($value, ENT_QUOTES, "UTF-8");
}
function is_course_code(string $value): bool {
 // INTE followed by 4 digits (e.g., INTE3363)
 return (bool) preg_match('/^INTE\d{4}$/', $value);
}
function clean_text(string $value): string {
 // Trim + remove extra whitespace (simple, beginner-friendly)
 $value = trim($value);
 $value = preg_replace('/\s+/', ' ', $value);
 return $value ?? '';
}