# Lab 07 — Validation & Error Handling (JavaScript + PHP) **
## 1) How to Run
1. Start **Apache** in XAMPP.
2. Put this folder in: `C:\xampp\htdocs\winter3363\lab07\` 
3. Testing URL: `http://localhost/3363winter/lab07/index.php`
---

## 2) Files Included (check)
Student Name: Vanessa Caldas
 **Submission Date:** 03/01/2026
Testing URL:
[X]`index.php`
[X]``process.php`
[X]``includes/helpers.php`
[X]``assets/validation.js`
[X]``assets/style.css`
[X]``data/submissions.jsonl` 
[X]``logs/errors.log`
---
## 3) Validation Completed (check) ### JavaScript (client-side)
- [X] Required fields blocked
- [X] Email format checked
- [X] Course code format checked (INTE####) 
- [X] Rating checked (1–5)
- [X] Agree checkbox required
- [X] Errors show beside fields
- [X] Prevent submit when invalid
### PHP (server-side)
- [X] Validates the same rules again 
- [X] Shows errors beside fields
- [X] Keeps sticky values (old input stays) 
- [X] Uses `try/catch` for saving file
- [X] Logs errors to `logs/errors.log`
---
## 4) Testing Checklist (Required) Fill in Pass/Fail.
| Test | Pass/Fail |
|------|----------|
| Empty submit shows errors | PASS |
| Invalid email blocked | PASS |
| Invalid course code blocked | PASS |
| Rating out of range blocked | PASS |
| Agree unchecked blocked | PASS |
| Disable JS (comment out script tag) → PHP still blocks invalid data | PASS |
| Valid submit saves to `submissions.jsonl` | PASS |
---
Fill in 1–2 sentences for each.
**JavaScript validation is good for:** 
Showing errors quickly before submitting.
**JavaScript validation is NOT reliable for security because:** 
It can be disabled and bypassed.
**PHP validation is important because:** 
It protects the server and validates data.
**One example from my testing (disable JS) that proved PHP is needed because:** When I disabled JavaScript, PHP still blocked invalid data.